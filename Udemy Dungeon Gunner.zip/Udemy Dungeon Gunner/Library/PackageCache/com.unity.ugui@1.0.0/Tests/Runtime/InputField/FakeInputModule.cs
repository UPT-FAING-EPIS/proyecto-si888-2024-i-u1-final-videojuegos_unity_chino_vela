using UnityEngine.EventSystems;

namespace InputfieldTests
{
    public class FakeInputModule : BaseInputModule
    {
        public override void Process()
        {
        }
    }
}
